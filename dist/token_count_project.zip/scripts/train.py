import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from agents.modeling_agent import ModelingAgent

import joblib
from utils.feature_serializer import load_features

# 1. Load engineered features
data_path = 'data/preprocessed/preprocessed_features.parquet'
if not os.path.exists(data_path):
    data_path = 'data/preprocessed/preprocessed_features.csv'
df = load_features(data_path) if data_path.endswith('.parquet') else None
if df is None:
    import pandas as pd
    df = pd.read_csv(data_path)

# 2. Instantiate ModelingAgent (assume target is 'TokenCount')
agent = ModelingAgent(df, target='TokenCount')

# 3. Train baselines and models
agent.train_baseline()
agent.train_glms()
agent.train_trees()
agent.tune_parameters()

# 4. Save best model (choose best from agent.models, here LightGBM preferred)
best_model = agent.models.get('lgbm') or agent.models.get('xgbm')
os.makedirs('models', exist_ok=True)
joblib.dump(best_model, 'models/best_model.pkl')
print('Best model saved to models/best_model.pkl')
