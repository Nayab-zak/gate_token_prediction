import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import joblib
import pandas as pd
from agents.evaluation_agent import EvaluationAgent
from utils.feature_serializer import load_features

# 1. Load model and hold-out set
def main():
    model_path = 'models/best_model.pkl'
    holdout_path = 'data/preprocessed/preprocessed_features.csv'
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model not found: {model_path}")
    if not os.path.exists(holdout_path):
        raise FileNotFoundError(f"Hold-out set not found: {holdout_path}")
    model = joblib.load(model_path)
    df_holdout = pd.read_csv(holdout_path, parse_dates=['MoveDate'])

    # 2. Instantiate EvaluationAgent
    agent = EvaluationAgent(model, df_holdout)

    # 3. Run evaluation steps
    metrics = agent.score_holdout()
    slice_df = agent.score_slice()
    rolling_df = agent.rolling_test()
    psi_df = agent.psi(features=['TokenCount','ContainerCount'])
    agent.report(path='reports/final_report.md')
    print('Evaluation complete. Metrics:', metrics)
    print('Slice breakdown saved. Rolling backtest and drift detection complete.')

if __name__ == '__main__':
    main()
