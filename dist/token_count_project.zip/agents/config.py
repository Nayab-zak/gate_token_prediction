import os
from dotenv import load_dotenv

# Load environment variables from .env file (only once, when config is imported)
load_dotenv()

# Centralized config access
INPUT_FILE_PATH = os.getenv("INPUT_FILE_PATH", "data/Token_Input_data_desig.xlsx")
