import pandas as pd
import numpy as np
import os
from typing import List
from utils.logger import setup_logging, get_logger
from utils.footsteps import track_step
import matplotlib.pyplot as plt

setup_logging()

class EvaluationAgent:
    def __init__(self, model, df_holdout: pd.DataFrame, logger=None):
        self.model = model
        self.df_holdout = df_holdout.copy()
        self.logger = logger or get_logger('evaluation_agent')

    @track_step('score_holdout')
    def score_holdout(self) -> dict:
        """
        Score model on the last 3 months of holdout data, returning metrics.
        """
        df = self.df_holdout.copy()
        if 'MoveDate' in df.columns:
            last_date = df['MoveDate'].max()
            cutoff = last_date - pd.DateOffset(months=3)
            df = df[df['MoveDate'] >= cutoff]
        y_true = df['TokenCount']
        y_pred = self.model.predict(df.drop(columns=['TokenCount', 'MoveDate'], errors='ignore'))
        mae = np.mean(np.abs(y_true - y_pred))
        rmse = np.sqrt(np.mean((y_true - y_pred) ** 2))
        mape = np.mean(np.abs((y_true - y_pred) / (y_true + 1e-8)))
        self.logger.info(f"Holdout MAE: {mae:.2f}, RMSE: {rmse:.2f}, MAPE: {mape:.2%}")
        return {'MAE': mae, 'RMSE': rmse, 'MAPE': mape}

    @track_step('score_slice')
    def score_slice(self, by: List[str] = ['is_holiday','is_weekend']) -> pd.DataFrame:
        """
        Return a breakdown DataFrame of metrics by specified columns.
        """
        df = self.df_holdout.copy()
        y_true = df['TokenCount']
        y_pred = self.model.predict(df.drop(columns=['TokenCount', 'MoveDate'], errors='ignore'))
        df['y_true'] = y_true
        df['y_pred'] = y_pred
        results = []
        for keys, group in df.groupby(by):
            mae = np.mean(np.abs(group['y_true'] - group['y_pred']))
            rmse = np.sqrt(np.mean((group['y_true'] - group['y_pred']) ** 2))
            results.append(dict(zip(by, keys if isinstance(keys, tuple) else [keys])))
            results[-1].update({'MAE': mae, 'RMSE': rmse, 'count': len(group)})
        breakdown = pd.DataFrame(results)
        self.logger.info(f"Slice breakdown by {by}:\n{breakdown}")
        return breakdown

    @track_step('rolling_test')
    def rolling_test(self, window: int = 168, step: int = 24) -> pd.DataFrame:
        """
        Simulate retrain+forecast with a rolling window, returning stability results.
        """
        df = self.df_holdout.copy().sort_values('MoveDate')
        results = []
        for start in range(0, len(df) - window, step):
            train = df.iloc[start:start+window]
            test = df.iloc[start+window:start+window+step]
            if len(test) == 0:
                break
            X_train = train.drop(columns=['TokenCount', 'MoveDate'], errors='ignore')
            y_train = train['TokenCount']
            X_test = test.drop(columns=['TokenCount', 'MoveDate'], errors='ignore')
            y_test = test['TokenCount']
            self.model.fit(X_train, y_train)
            y_pred = self.model.predict(X_test)
            mae = np.mean(np.abs(y_test - y_pred))
            rmse = np.sqrt(np.mean((y_test - y_pred) ** 2))
            results.append({'start': train['MoveDate'].min(), 'end': test['MoveDate'].max(), 'MAE': mae, 'RMSE': rmse})
        res_df = pd.DataFrame(results)
        self.logger.info(f"Rolling test results:\n{res_df}")
        return res_df

    @track_step('psi')
    def psi(self, features: List[str], threshold: float = 0.2) -> pd.DataFrame:
        """
        Compute Population Stability Index (PSI) month-over-month for given features.
        """
        df = self.df_holdout.copy()
        df['month'] = df['MoveDate'].dt.to_period('M')
        psi_results = []
        for feature in features:
            prev_dist = None
            for month, group in df.groupby('month'):
                dist = group[feature].value_counts(normalize=True)
                if prev_dist is not None:
                    psi = np.sum((dist - prev_dist) * np.log((dist + 1e-8) / (prev_dist + 1e-8)))
                    psi_results.append({'feature': feature, 'month': month, 'psi': psi})
                prev_dist = dist
        psi_df = pd.DataFrame(psi_results)
        flagged = psi_df[psi_df['psi'] > threshold]
        self.logger.info(f"PSI flagged features:\n{flagged}")
        return psi_df

    @track_step('report')
    def report(self, path: str = 'reports/evaluation_report.md'):
        """
        Write a summary report with plots and tables.
        """
        os.makedirs(os.path.dirname(path), exist_ok=True)
        metrics = self.score_holdout()
        psi_df = self.psi(features=['TokenCount','ContainerCount'])
        with open(path, 'w') as f:
            f.write(f"# Evaluation Report\n\n")
            f.write(f"## Holdout Metrics\n{metrics}\n\n")
            f.write(f"## PSI\n{psi_df.to_markdown()}\n\n")
        # Example plot
        plt.figure(figsize=(8,4))
        self.df_holdout['TokenCount'].plot(label='Actual')
        y_pred = self.model.predict(self.df_holdout.drop(columns=['TokenCount', 'MoveDate'], errors='ignore'))
        plt.plot(self.df_holdout['MoveDate'], y_pred, label='Predicted')
        plt.legend()
        plt.title('Actual vs Predicted TokenCount')
        plt.tight_layout()
        plot_path = path.replace('.md', '.png')
        plt.savefig(plot_path)
        self.logger.info(f"Report written to {path} and plot saved to {plot_path}")
