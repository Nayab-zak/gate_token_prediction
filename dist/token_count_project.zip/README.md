# Predictive Modeling Token Prediction

## 1. Project Overview
This project provides a modular framework for predictive modeling, focusing on token prediction. It is structured around agent-based components for data loading, sanitization, exploratory data analysis (EDA), feature engineering, and more. The design emphasizes extensibility, robust logging, and ease of use for both local and production environments.

## 2. Installation & Setup

### Environment Variables
- Configure environment variables as needed, e.g., `LOG_LEVEL` for logging verbosity.
- Database connection strings and input file paths should be set in `config.py` or via a `.env` file.

### Install Dependencies
```bash
pip install -r requirements.txt
```

### .env File (Optional)
Create a `.env` file in the project root for sensitive configuration (e.g., DB credentials, API keys).

## 3. Agents & Modules
- **DataLoaderAgent**: Loads data from files (CSV, Excel) or databases (Vertica, etc.).
- **SanitizationAgent**: Cleans and sanitizes DataFrames (type conversion, missing values, outlier removal).
- **EDADashboardAgent**: Generates EDA dashboards and visualizations (Streamlit, etc.).
- **FeatureEngineeringAgent**: Handles feature creation and transformation.
- *(More agents can be added for modeling, evaluation, etc.)*

## 4. Running Locally

### Streamlit Dashboard
```bash
streamlit run agents/eda_dashboard_agent.py
```

### Running Scripts
```bash
python agents/data_laoder_agent.py
python agents/sanitization_agent.py
```

## 5. Logging & Logs Directory
- All agents use a centralized logging utility (`utils/logger.py`).
- Logs are written to the `logs/` directory, with separate log files for each agent and a root log.
- Log level is configurable via the `LOG_LEVEL` environment variable (e.g., `export LOG_LEVEL=DEBUG`).
- Logs are output to both file and console.

## 6. Future Steps
- Add support for additional database connections and authentication.
- Implement advanced modeling and evaluation agents.
- Expand configuration management and deployment options.
- Integrate with CI/CD and cloud platforms.
